# COVID Weekly Map App
# Last Updated 4/15/2021
# POC: Jonathan Gross, MPH, CPH, jonathan.gross@baltimorecity.gov
# Baltimore City Health Department
# This code is for educational purposes and comes with no guarantees! 
# Sample data are fake data generated using random numbers. 
# R Version: 3.5

# Use install.packages() first for the packages below - before the first time you run. Then comment out.
install.packages("readxl")
install.packages("dplyr")
install.packages("shiny")
install.packages("rgdal")
install.packages("sp")
install.packages("leaflet")
install.packages("plotly")
install.packages("kableExtra")
install.packages("shinythemes")

# Library
library(readxl)
library(dplyr)
library(shiny)
library(rgdal)
library(sp)
library(leaflet)
library(plotly)
library(kableExtra)
library(shinythemes)
#library(sf)
#library(markdown)
#library(stats)
#library(rgeos)

# Steps
# Read-in deidentified data
# Allow user to select week

# Read in deidentifed data---------------------------------
covid<-read.csv("./data/COVIDWEEK.csv")
covid <- covid %>% dplyr::select(CSA2010,week,cases,hospitalizations,deaths,nursing)

    # Most recent week used for input selector
    max_week<-max(covid$week)
        
# Read in CSA centroid shapefile
centroids<-readOGR("./data/CSA_CentroidsSHP.shp")

# Read in BNIA CSA outline polygons shapefile for Rates, Indicators,etc
bnia<-readOGR("./data/VS18.shp",stringsAsFactors = FALSE)

# Number of People 65 and older
bnia$Census_NUM<-as.numeric(as.character(bnia$Census_NUM))
bnia$tpop10<-as.numeric(as.character(bnia$tpop10))
bnia$Pop_16Plus<-as.numeric(as.character(bnia$Pop_16Plus))
bnia_dat<-as.data.frame(bnia) %>% select(CSA2010,tpop10,Census_NUM,Pop_16Plus)

# Read-in Lab data----------------------------
covid_lab <- read.csv("./data/COVIDWEEK_Lab.csv")
covid_lab$CSA2010<-covid_lab$csa2010

# Read-in Vax data----------------------------
covid_vax <- read.csv("./data/COVIDWEEK_Vax.csv")
covid_vax$CSA2010<-covid_vax$csa2010
covid_vax <- covid_vax %>% dplyr::select(-csa2010) 
covid_vax<-covid_vax %>% filter((CSA2010!=""))

# Read in NHP 2017 data for Correlation Explorer
nhp2017<- read_excel("./data/NHP.xlsx")
nhp2017<- nhp2017 %>% dplyr::filter(CSA!="Baltimore City")
nhp2017<- nhp2017 %>% dplyr::rename(CSA2010=CSA)
nhp2017<- nhp2017 %>% select(-c("NHPLink"))
nhp2017<-as.data.frame(nhp2017)
rownames(nhp2017)<-nhp2017$CSA2010
nhp2017_raw<-nhp2017

# Dont show any misc error message
#options(shiny.sanitize.errors = TRUE)

# Define UI for application ----------------------------------------------
ui <- fluidPage(
    titlePanel("Baltimore City: Coronavirus Weekly Viewer - FAKE DEMO DATA"),
    
    # Pick a different theme.
    #shinythemes::themeSelector(),
    #theme = shinytheme("united"),
    
    sidebarLayout(
        sidebarPanel(
            width=3,
            numericInput("start_week",label="Start Week",min=1,max=104, value=51), #max_week
            textOutput("returned"),
            br(),
            numericInput("end_week",label="End Week",min=1,max=104, value=52), #max_week-1
            textOutput("returned2"),
            h5("Notes: The tabs for Lab Tests and Correlations will take a few seconds to display. Weeks are consecutive 7-day periods from January 1st (vs calendar weeks). First week of 2021 = 53. Week 52 of 2020 has a few extra days worth of cases. Rates are per 1,000 population.", style="color:red"),
            h5("Excludes Nursing Home Cases & Correctional Facilities - EXCEPT for the Percent of Total Population Tested. Vaccination maps use Date of First Dose for ALL people vaccinated.")
        ),
        
        mainPanel(
          width=9,
         # Change font size for tab text
          # tags$style(type='text/css',
          #            ".nav-tabs {font-size: 11pt;padding:0px}"
          #            ),
            navbarPage(title="Menu",
              navbarMenu("Case Data",
                tabPanel("Counts",leafletOutput("count_map",height=520)),
                tabPanel("Rates",leafletOutput("rate_map",height=520)),
                tabPanel("Deaths",leafletOutput("death_map",height=520)),
                tabPanel("Case Fatality Rate",leafletOutput("cfr_map",height=520)),
                tabPanel("Mortality Rate",leafletOutput("mort_map",height=520)),
                tabPanel("% Hospitalized",leafletOutput("hosp_map",height=520)),
                tabPanel("Hospitalization Rate",leafletOutput("hosp_map2",height=520))
              ),
              navbarMenu("Lab",
                tabPanel("% Positive",leafletOutput("perpos_map",height=520)),
                tabPanel("% Tested (All)",leafletOutput("pertested_map",height=520)),
                tabPanel("# Tested",leafletOutput("tested_map",height=520))
                
              ),
            
              tabPanel("Correlations",uiOutput("exp"),uiOutput("outcome"),textOutput("result"),plotlyOutput("corr_plot",height=325)),
          
              navbarMenu("Priority Areas",
                tabPanel("Priority-Select",h5("Takes rank of variable and allows user to select weights for priority areas. If you do not want to include a variable, add a weight of 0. Consider expanding number of weeks if you want more certainty. Deaths and Hospitalizations also lag. Click the next tab to see results. Formula= (Rank - Quantile of Factor1 x Weight1)+(Rank 2 x weight2)+(Rank 3 x Weight3)"),uiOutput("first"),uiOutput("firstw"),uiOutput("second"),uiOutput("secondw"),uiOutput("third"),uiOutput("thirdw")),
                tabPanel("Priority-Results",dataTableOutput("prior_table")),
                tabPanel("Priority-Map",leafletOutput("priority_map",height=520))
               
              ),
              
              tabPanel("Stat Table",dataTableOutput("stattable")),       
              
              navbarMenu("Vaccine Data",
                tabPanel("# Vax",leafletOutput("numbervax",height=520)),
                tabPanel("% Vax",leafletOutput("pervax",height=520)),
                tabPanel("% Vax: Complete",leafletOutput("pervax2",height=520)),
                tabPanel("% Vax Eligible",leafletOutput("vax_eligible1",height=520)),
                tabPanel("% Vax Eligible - Complete",leafletOutput("vax_eligible2",height=520)),
                tabPanel("% Vax 65+",leafletOutput("pervax65",height=520)),
                tabPanel("% Vax 65+: Complete",leafletOutput("pervax652",height=520)),
                tabPanel("% Overdue",leafletOutput("overdue",height=520))
                #tabPanel("Antibody Testing-To do"),
              ),
              
             
              navbarMenu("Vaccine Table",
                         tabPanel("Vax Table",dataTableOutput("vaxtable")),
                         tabPanel("CSA Statistics",verbatimTextOutput("quick_stats"))
              ),
              
         
                tabPanel("Notes","Case, Rate, Hospitalized, Death, Percent Positive and Number tested tabs = Non-Nursing Home Cases. 
                Percent Positive calculated at individual-level. Percent of Population Tested includes all cases.")
              
            )
        )
    )
)

# Define server logic --------------------------------
server <- function(input, output) {
    
    # Inputs by User
    
    # Start Date for Week
    # Get different week numbers via different week format
    output$returned<-renderText({
      returned<-if(input$start_week<53){
        as.Date(paste(2020,input$start_week, 1, sep="-"), "%Y-%U-%u")-7
      } else if(input$start_week>=53){
        as.Date(paste(2021,input$start_week-52, 1, sep="-"), "%Y-%U-%u")-3
      }
      paste0("First day of starting week: ", returned)
    })
    
    # End Date for Week
    output$returned2<-renderText({
      returned2<-if(input$end_week<53){
        as.Date(paste(2020,input$end_week, 1, sep="-"), "%Y-%U-%u")
      }else{
        as.Date(paste(2021,input$end_week-52, 1, sep="-"), "%Y-%U-%u")+3
      }    
      paste0("Last day of ending week: ",returned2) 
    })

    # Map: Cases - Excluding Nursing Home Cases------------------
    output$count_map<-renderLeaflet({
        covid_count <- covid %>% dplyr::filter(nursing==0)
        covid_count <-aggregate(cases~CSA2010+week,covid_count,FUN=sum)
        covid_count_map<-covid_count %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        covid_count_map<-aggregate(cases~CSA2010,covid_count_map,FUN=sum)
        count_centroids<-sp::merge(centroids,covid_count_map,by=c("CSA2010"))
        count_centroids$cases<-ifelse(is.na(count_centroids$cases),0,count_centroids$cases)
          
        # Labels
        map_out_label<-paste0("CSA: ",count_centroids$CSA2010,"<br>","Cases: ",count_centroids$cases)
        
        leaflet(count_centroids) %>% addTiles()%>%
            setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
            addCircleMarkers(radius=ntile(count_centroids$cases,4)*5,
                             color = ~colorNumeric("YlOrRd", cases)(cases), weight = 1,  opacity = 1.0, fillOpacity = .85,
                             label=lapply(map_out_label,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
                             addLegend(position="bottomright",pal = colorNumeric("YlOrRd", count_centroids$cases),
                                       values = count_centroids$cases,title="Number of Cases"
                                      
                                       )
        
                                     })
    
    # Map: Rates - Excluding Nursing Home Cases---------------------------
    output$rate_map<-renderLeaflet({
        covid_rate <- covid %>% dplyr::filter(nursing==0)
        covid_rate_map<-covid_rate %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        covid_rate_map<-aggregate(cases~CSA2010,covid_rate_map,FUN=sum)
        rates<-sp::merge(bnia,covid_rate_map,by=c("CSA2010"))
        rates$calc1<-rates$cases*1000
        rates$tpop<-as.numeric(as.character(rates$tpop10))
        rates$rate<-round(rates$calc1/rates$tpop,1)

        # Labels
        map_out_label_rates<-paste0("CSA: ",rates$CSA2010,"<br>","Cases: ",rates$cases,"<br>","Popn: ",rates$tpop10,"<br>","Rate: ",rates$rate)

        leaflet(rates) %>% addTiles()%>%
             setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
             addPolygons(color = ~colorQuantile("YlOrRd", rate,n=5)(rate), weight = 1,  opacity = 1.0, fillOpacity = .5,
                        label=lapply(map_out_label_rates,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
                        addLegend(position="bottomright",pal = colorQuantile("YlOrRd", rates$rate),
                                  values = rates$rate,title=" Rate per 1000 Popn.",
                                  labFormat = function(type, cuts, p) {
                                      n = length(cuts)
                                      p = paste0(round(p * 100), '%')
                                      cuts = paste0(formatC(cuts[-n]), " - ", formatC(cuts[-1]))
                                      # mouse over the legend labels to see the percentile ranges
                                      paste0(
                                          '<span title="', p[-n], " - ", p[-1], '">', cuts,
                                          '</span>')
                                  })
        
    })
        
    # Map: Deaths - Excluding Nursing Home Cases -----------------------------------
    output$death_map<-renderLeaflet({
            death_count <- covid %>% dplyr::filter(nursing==0)
            death_count <-aggregate(deaths~CSA2010+week,death_count,FUN=sum)
            death_count_map<-death_count %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
            death_count_map<-aggregate(deaths~CSA2010,death_count_map,FUN=sum)
            death_centroids<-sp::merge(centroids,death_count_map,by=c("CSA2010"))
            death_centroids$deaths<-ifelse(is.na(death_centroids$deaths),0,death_centroids$deaths)
            
            # Labels
            map_out_label_deaths<-paste0("CSA: ",death_centroids$CSA2010,"<br>","Deaths: ",death_centroids$deaths)
            
            # Factor Colors/symbols
            factpal <- colorFactor("viridis", death_centroids$deaths)
            
            leaflet(death_centroids) %>% addTiles()%>%
                setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
                addCircleMarkers(radius=death_centroids$deaths*2+15,
                                 color = ~factpal(deaths), weight = 1,  opacity = 1.0, fillOpacity = .85,
                                 label=lapply(map_out_label_deaths,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
                addLegend(position="bottomright",pal = colorFactor("viridis",death_centroids$deaths),
                          values = death_centroids$deaths,title="Number of Deaths")
            
        })
    
    # Map: CFR - Excluding Nursing Home Cases -----------------------------------
    output$cfr_map<-renderLeaflet({
      cfr <- covid %>% dplyr::filter(nursing==0)
      cfr_rate_map<-cfr %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      cfr_rate_map<-aggregate(.~CSA2010,cfr_rate_map,FUN=sum)
      cfr_rates<-sp::merge(bnia,cfr_rate_map,by=c("CSA2010"))
      cfr_rates$cfr_rate<-round(((as.numeric(as.character(cfr_rates$deaths)))/as.numeric(as.character(cfr_rates$cases)))*100,1)
      
      # Labels
      map_out_label_cfr<-paste0("CSA: ",cfr_rates$CSA2010,"<br>","Deaths: ",cfr_rates$deaths,"<br>","Cases: ",cfr_rates$cases,"<br>","CFR: ",cfr_rates$cfr_rate)
      
      
      leaflet(cfr_rates) %>% addTiles()%>%
        setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
        addPolygons(color = ~colorBin("YlOrRd",cfr_rate,4,pretty = TRUE)(cfr_rate), weight = 1,  opacity = 1.0, fillOpacity = .65,
                    label=lapply(map_out_label_cfr,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
        addLegend(position="bottomright",pal = colorBin("YlOrRd", cfr_rates$cfr_rate,4,pretty=TRUE),
                  values = cfr_rates$rate,title="Case Fatality Rate (CFR)")
      
    })
    
    # Map: Mortality Rate - Excluding Nursing Home Cases -----------------------------------
    output$mort_map<-renderLeaflet({
      mort_rate <- covid %>% dplyr::filter(nursing==0)
      mort_rate_map<-mort_rate %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      mort_rate_map<-aggregate(.~CSA2010,mort_rate_map,FUN=sum)
      mort_rates<-sp::merge(bnia,mort_rate_map,by=c("CSA2010"))
      mort_rates$m_rate<-round(((as.numeric(as.character(mort_rates$deaths))*1000)/as.numeric(as.character(mort_rates$tpop10))),1)
      
      # Labels
      map_out_label_mort<-paste0("CSA: ",mort_rates$CSA2010,"<br>","Deaths: ",mort_rates$deaths,"<br>","Population: ",mort_rates$tpop10,"<br>","Rate: ",mort_rates$m_rate)
      
      
      leaflet(mort_rates) %>% addTiles()%>%
        setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
        addPolygons(color = ~colorBin("YlOrRd",m_rate,4,pretty = TRUE)(m_rate), weight = 1,  opacity = 1.0, fillOpacity = .65,
                    label=lapply(map_out_label_mort,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
        addLegend(position="bottomright",pal = colorBin("YlOrRd", mort_rates$m_rate,4,pretty=TRUE),
                  values = mort_rates$rate,title="Mortality Rate")
      
    })
    
    # Map: Percent Hospitalized - Excluding Nursing Home Cases -----------------------------------
    output$hosp_map<-renderLeaflet({
        hosp_rate <- covid %>% dplyr::filter(nursing==0)
        hosp_rate_map<-hosp_rate %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        hosp_rate_map<-aggregate(.~CSA2010,hosp_rate_map,FUN=sum)
        hosp_rate_map$percent<-round((hosp_rate_map$hospitalizations/hosp_rate_map$cases)*100,1)
        hosp_rates<-sp::merge(bnia,hosp_rate_map,by=c("CSA2010"))
        
        # Labels
        map_out_label_hosp<-paste0("CSA: ",hosp_rates$CSA2010,"<br>","Cases: ",hosp_rates$cases,"<br>","Hospitalized: ",hosp_rates$hospitalizations,"<br>","Percent: ",hosp_rates$percent)
        
        leaflet(hosp_rates) %>% addTiles()%>%
            setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
            addPolygons(color = ~colorBin("YlOrRd", percent,4,pretty = TRUE)(percent), weight = 1,  opacity = 1.0, fillOpacity = .65,
                        label=lapply(map_out_label_hosp,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
            addLegend(position="bottomright",pal = colorBin("YlOrRd", hosp_rates$percent,4,pretty=TRUE),
                      values = hosp_rates$percent,title=" Percent Hospitalized")
                    
        
    })
    
    # Map: Hospitalization Rate - Excluding Nursing Home Cases -----------------------------------
    output$hosp_map2<-renderLeaflet({
      hosp_rate <- covid %>% dplyr::filter(nursing==0)
      hosp_rate_map<-hosp_rate %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      hosp_rate_map<-aggregate(.~CSA2010,hosp_rate_map,FUN=sum)
      hosp_rates<-sp::merge(bnia,hosp_rate_map,by=c("CSA2010"))
      hosp_rates$h_rate<-round(((as.numeric(as.character(hosp_rates$hospitalizations))*1000)/as.numeric(as.character(hosp_rates$tpop10))),1)
      
      # Labels
      map_out_label_hosp<-paste0("CSA: ",hosp_rates$CSA2010,"<br>","Hospitalized: ",hosp_rates$hospitalizations,"<br>","Population: ",hosp_rates$tpop10,"<br>","Rate: ",hosp_rates$h_rate)
      
      
      leaflet(hosp_rates) %>% addTiles()%>%
        setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
        addPolygons(color = ~colorBin("YlOrRd", h_rate,4,pretty = TRUE)(h_rate), weight = 1,  opacity = 1.0, fillOpacity = .65,
                    label=lapply(map_out_label_hosp,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
        addLegend(position="bottomright",pal = colorBin("YlOrRd", hosp_rates$h_rate,4,pretty=TRUE),
                  values = hosp_rates$rate,title="Hospitalization Rate")
      
    })
    # Map: Lab Percent Positive ---------------------------------------
    output$perpos_map<-renderLeaflet({
        perpos <- covid_lab %>% dplyr::filter(nursing==0)
        perpos_map<- perpos %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
    
        # Find First CSA, Summarize test results by patient
        covid_lab2<-perpos_map
        
        raw<- covid_lab2 %>% arrange(id, week) %>% group_by(id) %>% 
            filter(row_number()==1)
        
        covid_firstcsa<-raw %>% dplyr::select(id,CSA2010)
        
        # Summarize records by patient
        perpos_map<-aggregate(.~id,covid_lab2,FUN=sum)
        perpos_map$recs<-1
        perpos_map <- perpos_map %>% dplyr::select(-CSA2010)
        perpos_map<-merge(perpos_map,covid_firstcsa,by=c("id"))
        
        # recode
        perpos_map$pos<-ifelse(perpos_map$pos>=1,1,0)
        perpos_map$neg<-ifelse(perpos_map$neg>=1,1,0)
        #perpos_map$inconcl<-ifelse(perpos_map$inconcl>=1,1,0)
        #perpos_map$missing<-ifelse(perpos_map$missing>=1,1,0)
        perpos_map$nursing<-ifelse(perpos_map$nursing>=1,1,0)
        
        # Aggregate by CSA
        perpos_map<-aggregate(.~CSA2010,perpos_map,FUN=sum)
        perpos_map$percent<-round((perpos_map$pos/perpos_map$recs)*100,1)
        percent_positive<-sp::merge(bnia,perpos_map,by=c("CSA2010"))
        
        # Labels
        map_out_label_perpos<-paste0("CSA: ",percent_positive$CSA2010,"<br>","Positive: ",percent_positive$pos,"<br>","Tested ",percent_positive$recs,"<br>","Percent: ",percent_positive$percent)
        
        leaflet(percent_positive) %>% addTiles()%>%
            setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
            addPolygons(color = ~colorQuantile("YlOrRd", percent)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                        label=lapply(map_out_label_perpos,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
            addLegend(position="bottomright",pal = colorQuantile("YlOrRd", percent_positive$percent),
                      values = percent_positive$percent,title=" Percent Positive",
                      labFormat = function(type, cuts, p) {
                          n = length(cuts)
                          p = paste0(round(p * 100), '%')
                          cuts = paste0(formatC(cuts[-n]), " - ", formatC(cuts[-1]))
                          # mouse over the legend labels to see the percentile ranges
                          paste0(
                              '<span title="', p[-n], " - ", p[-1], '">', cuts,
                              '</span>')
                                                        })
                                            })
    
        # Map: Lab Percent of Population Tested (ALL)---------------------------------------
        output$pertested_map<-renderLeaflet({
            pertested <- covid_lab
            per_tested<- pertested %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
            
            # Find First CSA, Summarize test results by patient
            covid_lab3<-per_tested
            
            raw2<- covid_lab3 %>% arrange(id, week) %>% group_by(id) %>% 
                filter(row_number()==1)
            
            covid_firstcsa<-raw2 %>% dplyr::select(id,CSA2010)
            
            # Summarize records by patient
            pertested_map<-aggregate(.~id,covid_lab3,FUN=sum)
            pertested_map<- pertested_map %>% dplyr::select(-CSA2010)
            pertested_map<-merge(pertested_map,covid_firstcsa,by=c("id"))
            pertested_map$recs<-1
            
            # recode
            pertested_map$pos<-ifelse(pertested_map$pos>=1,1,0)
            pertested_map$neg<-ifelse(pertested_map$neg>=1,1,0)
            #pertested_map$inconcl<-ifelse(pertested_map$inconcl>=1,1,0)
            #pertested_map$missing<-ifelse(pertested_map$missing>=1,1,0)
            pertested_map$nursing<-ifelse(pertested_map$nursing>=1,1,0)
            
            # Aggregate by CSA
            pertested_map<-aggregate(.~CSA2010,pertested_map,FUN=sum)
            percent_tested<-sp::merge(bnia,pertested_map,by=c("CSA2010"))
            percent_tested$tpop10<-as.numeric(as.character(percent_tested$tpop10))
            percent_tested$percent<-round((percent_tested$recs/percent_tested$tpop10)*100,1)

            # Labels
            map_out_label_pertested<-paste0("CSA: ",percent_tested$CSA2010,"<br>","Tested: ",percent_tested$recs,"<br>","Population: ",percent_tested$tpop10,"<br>","Percent: ",percent_tested$percent)

            leaflet(percent_tested) %>% addTiles()%>%
                setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
                addPolygons(color = ~colorQuantile("RdYlBu", percent)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                            label=lapply(map_out_label_pertested,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
                addLegend(position="bottomright",pal = colorQuantile("RdYlBu", percent_tested$percent),
                          values = percent_tested$percent,title=" Percent Tested",
                          labFormat = function(type, cuts, p) {
                              n = length(cuts)
                              p = paste0(round(p * 100), '%')
                              cuts = paste0(formatC(cuts[-n]), " - ", formatC(cuts[-1]))
                              # mouse over the legend labels to see the percentile ranges
                              paste0(
                                  '<span title="', p[-n], " - ", p[-1], '">', cuts,
                                  '</span>')
                          })
        })

            # Map: Number Tested (Excluding Nursing Homes) -----------------------------------
            output$tested_map<-renderLeaflet({
                tested_count <- covid_lab %>% dplyr::filter(nursing==0)
                tested_count_map<-tested_count %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
                
                # Find First CSA, Summarize test results by patient
                covid_lab4<-tested_count_map
                
                raw3<- covid_lab4 %>% arrange(id, week) %>% group_by(id) %>% 
                    filter(row_number()==1)
                
                covid_firstcsa<-raw3 %>% dplyr::select(id,CSA2010)
                
                # Summarize records by patient
                tested_map<-aggregate(.~id,covid_lab4,FUN=sum)
                
                tested_map<- tested_map %>% dplyr::select(-CSA2010)
                tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
                
                # recode
                tested_map$pos<-ifelse(tested_map$pos>=1,1,0)
                tested_map$neg<-ifelse(tested_map$neg>=1,1,0)
                #tested_map$inconcl<-ifelse(tested_map$inconcl>=1,1,0)
                #tested_map$missing<-ifelse(tested_map$missing>=1,1,0)
                tested_map$nursing<-ifelse(tested_map$nursing>=1,1,0)
                tested_map$recs<-1
                
                # Aggregate by CSA
                tested_count_map<-aggregate(recs~CSA2010,tested_map,FUN=sum)
                tested_centroids<-sp::merge(centroids,tested_count_map,by=c("CSA2010"))

                # Labels
                map_out_label_tested<-paste0("CSA: ",tested_centroids$CSA2010,"<br>","Tested: ",tested_centroids$recs)

                # Factor Colors/symbols
                factpal <- colorNumeric("viridis", tested_centroids$recs)

                leaflet(tested_centroids) %>% addTiles()%>%
                    setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
                    addCircleMarkers(radius=ntile(tested_centroids$recs,4)*5,
                                     color = ~factpal(recs), weight = 1,  opacity = 1.0, fillOpacity = .85,
                                     label=lapply(map_out_label_tested,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
                    addLegend(position="bottomright",pal = colorNumeric("viridis",tested_centroids$recs),
                              values = tested_centroids$recs,title="Number Tested")

            })
    
    # Correlation Explorer--------------------------------------
    
    dataInput<-reactive({
      # Rates
      covid_rate <- covid %>% dplyr::filter(nursing==0)
      covid_rate_map<-covid_rate %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      covid_rate_map<-aggregate(.~CSA2010,covid_rate_map,FUN=sum)
      rates<-sp::merge(bnia,covid_rate_map,by=c("CSA2010"))
      rates$calc1<-rates$cases*1000
      rates$tpop10<-as.numeric(as.character(rates$tpop10))
      rates$COVID_Rate<-round(rates$calc1/as.numeric(rates$tpop10),1)
      rates$Percent_Hospitalized<-round((rates$hospitalizations/rates$cases)*100,1)
      rates$Case_Fatality<-round((rates$deaths/rates$cases)*100,1)
      rates$Mortality_Rate<-round((rates$deaths*1000)/as.numeric(rates$tpop10),2)
      rates<-as.data.frame(rates)
      rates<-rates %>% dplyr::select(CSA2010,cases,deaths,hospitalizations,COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality)
      
      
      # Indicators
      merged<-merge(nhp2017,rates,by=c("CSA2010"))
      
      #rownames(merged)<-merged$CSA2010
      perpos <- covid_lab %>% dplyr::filter(nursing==0)
      perpos_map<- perpos %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      
      # Find First CSA, Summarize test results by patient
      covid_lab2<-perpos_map
      
      raw<- covid_lab2 %>% arrange(id, week) %>% group_by(id) %>% 
        filter(row_number()==1)
      
      covid_firstcsa<-raw %>% dplyr::select(id,CSA2010)
      
      # Summarize records by patient
      perpos_map<-aggregate(.~id,covid_lab2,FUN=sum)
      perpos_map$recs<-1
      perpos_map <- perpos_map %>% dplyr::select(-CSA2010)
      perpos_map<-merge(perpos_map,covid_firstcsa,by=c("id"))
      
      # recode
      perpos_map$pos<-ifelse(perpos_map$pos>=1,1,0)
      perpos_map$neg<-ifelse(perpos_map$neg>=1,1,0)
      #perpos_map$inconcl<-ifelse(perpos_map$inconcl>=1,1,0)
      #perpos_map$missing<-ifelse(perpos_map$missing>=1,1,0)
      perpos_map$nursing<-ifelse(perpos_map$nursing>=1,1,0)
      
      # Aggregate by CSA
      perpos_map<-aggregate(.~CSA2010,perpos_map,FUN=sum)
      perpos_map$Percent_Positive<-round((perpos_map$pos/perpos_map$recs)*100,1)
      
      merged<-merge(merged,perpos_map,by=c("CSA2010"))
      merged$Percent_Tested<-round((merged$recs/merged$Population)*100,1)
      rownames(merged)<-merged$CSA2010
      
      # Add in Vaccine Data
      pertested <- covid_vax #%>% filter(Facilit)
      pertested<- pertested %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      pertested$recs<-pertested$vaccinated
      
      # Summarize records by CSA+ Week
      tested_map<-aggregate(.~CSA2010,pertested,FUN=sum)
      tested_map <- tested_map  %>% arrange(CSA2010, week)
      #tested_map<- tested_map %>% dplyr::select(-CSA2010)
      #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
      
      
      # Aggregate by CSA
      pertested_map<-aggregate(.~CSA2010,tested_map,FUN=sum)
      percent_tested<-sp::merge(bnia,pertested_map,by=c("CSA2010"))
      percent_tested$tpop10<-as.numeric(as.character(percent_tested$tpop10))
      percent_tested$percent<-round((percent_tested$recs/percent_tested$tpop10)*100,1)
      percent_tested<-as.data.frame(percent_tested)
      percent_tested2<-percent_tested %>% dplyr::select(CSA2010,tpop10,percent,vaccinated,age65,Pop_16Plus,age16plus) 
      
      merged<-merge(merged,percent_tested2,by=c("CSA2010"))
      merged$Percent65_vax<-round((merged$age65)/((merged$Percent65Over/100)*merged$tpop10)*100,1)
      merged$Percent16_vax<-round((merged$age16plus/merged$Pop_16Plus)*100,1)
      merged<-merged%>% select(-id,-week,-csa2010,-pos,-neg,-nursing,-recs,-cases.y,-year,-tpop10,-Pop_16Plus,-age16plus,-age65)%>% rename(cases=cases.x,Percent_vax=percent)
                                                                                              
      })
    
    output$exp<-renderUI({
      #merged<-dataInput()
      #rownames(merged)<-merged$CSA2010
      selectInput('columns', 'Explanatory Variable', names(dataInput()),selected="MedianHHIncome")
    })
    
    output$outcome<-renderUI({
      # Rates
      #merged<-dataInput()
      #rownames(merged)<-merged$CSA2010
      selectInput('columns2', 'Outcomes', names(dataInput()),selected="Percent65_vax")
    })
    
    # Scatterplot
    output$corr_plot<-renderPlotly({
      
      #merged<-dataInput()
      #rownames(merged)<-merged$CSA2010
      
      # Prevent error message
      req(input$columns)
      
      # graphs
      scat<-ggplot(dataInput(),aes(!!as.name(x=input$columns),y=!!as.name(input$columns2)))+geom_point()
      #+geom_text(label=rownames(nhp2017),size=2,nudge_y=0.25,nudge_x =0.25)
      p<-ggplotly(scat)
      text<-paste("CSA: ",dataInput()$CSA2010,"<br>",input$columns,":", round(dataInput()[[input$columns]],digits=2),"<br>", input$columns2, ":", round(dataInput()[[input$columns2]],digits=2))
      style(p,text=text)
      #graph<-plot_ly(data = nhp2017, x =~!!input$select, y =~!!input$select2)
    })
      
      # # Correlation Statistics
      output$result<-renderText({
        
        # Rates
        covid_rate <- covid %>% dplyr::filter(nursing==0)
        covid_rate_map<-covid_rate %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        covid_rate_map<-aggregate(.~CSA2010,covid_rate_map,FUN=sum)
        rates<-sp::merge(bnia,covid_rate_map,by=c("CSA2010"))
        rates$calc1<-rates$cases*1000
        rates$tpop10<-as.numeric(as.character(rates$tpop10))
        rates$COVID_Rate<-round(rates$calc1/as.numeric(rates$tpop10),2)
        rates$Percent_Hospitalized<-round((rates$hospitalizations/rates$cases)*100)
        rates$Case_Fatality<-round((rates$deaths/rates$cases),100)
        rates$Mortality_Rate<-round((rates$deaths*1000)/as.numeric(rates$tpop10),2)
        rates<-as.data.frame(rates)
        rates<-rates %>% dplyr::select(CSA2010, COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality)
        
        # Prevent error message
        req(input$columns)
        
        # Indicators
        merged<-merge(nhp2017,rates,by=c("CSA2010"))
        perpos <- covid_lab %>% dplyr::filter(nursing==0)
        perpos_map<- perpos %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        
        # Find First CSA, Summarize test results by patient
        covid_lab2<-perpos_map
        
        raw<- covid_lab2 %>% arrange(id, week) %>% group_by(id) %>% 
          filter(row_number()==1)
        
        covid_firstcsa<-raw %>% dplyr::select(id,CSA2010)
        
        # Summarize records by patient
        perpos_map<-aggregate(.~id,covid_lab2,FUN=sum)
        perpos_map$recs<-1
        perpos_map <- perpos_map %>% dplyr::select(-CSA2010)
        perpos_map<-merge(perpos_map,covid_firstcsa,by=c("id"))
        
        # recode
        perpos_map$pos<-ifelse(perpos_map$pos>=1,1,0)
        perpos_map$neg<-ifelse(perpos_map$neg>=1,1,0)
        #perpos_map$inconcl<-ifelse(perpos_map$inconcl>=1,1,0)
        #perpos_map$missing<-ifelse(perpos_map$missing>=1,1,0)
        perpos_map$nursing<-ifelse(perpos_map$nursing>=1,1,0)
        
        # Aggregate by CSA
        perpos_map<-aggregate(.~CSA2010,perpos_map,FUN=sum)
        perpos_map$Percent_Positive<-round((perpos_map$pos/perpos_map$recs)*100,1)
        
        merged<-merge(merged,perpos_map,by=c("CSA2010"))
        merged$Percent_Tested<-round((merged$recs/merged$Population)*100,1)
        rownames(merged)<-merged$CSA2010
        
        # Add in Vaccine Data
        pertested <- covid_vax #%>% filter(Facilit)
        pertested<- pertested %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        pertested$recs<-pertested$vaccinated
       
        
        # Summarize records by CSA+ Week
        tested_map<-aggregate(.~CSA2010,pertested,FUN=sum)
        tested_map <- tested_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        pertested_map<-aggregate(.~CSA2010,tested_map,FUN=sum)
        percent_tested<-sp::merge(bnia,pertested_map,by=c("CSA2010"))
        percent_tested$tpop10<-as.numeric(as.character(percent_tested$tpop10))
        percent_tested$percent<-round((percent_tested$recs/percent_tested$tpop10)*100,1)
        percent_tested<-as.data.frame(percent_tested)
        percent_tested2<-percent_tested %>% dplyr::select(CSA2010,tpop10,percent,vaccinated,age65,Pop_16Plus,age16plus) 
        merged<-merge(merged,percent_tested2,by=c("CSA2010"))
        merged$Percent65_vax<-round((merged$age65)/((merged$Percent65Over/100)*merged$tpop10)*100,1)
        merged$Percent16_vax<-round((merged$age16plus/merged$Pop_16Plus*100),1)
        merged<-merged%>% select(-id,-week,-csa2010,-pos,-neg,-nursing,-recs,year,-tpop10)
        #merged$percent65_vax<-round((merged$age65/as.numeric(merged$Percent65Over*merged$Population))*100,1)
          
        # Corr Stat
        calc_cor<-round(cor(merged[[input$columns]],merged[[input$columns2]]),digits=2)
        calc_cor2<-round(cor(merged[[input$columns]],merged[[input$columns2]],method="spearman"),digits=2)
        paste("Pearson's R: ",calc_cor,"    |  Spearman's Rank: ",calc_cor2,".  If correlation statistics are NA, decrease the start week to include more data. NHP data uses slightly different denominators, so you may see small differences in rates and percentages on this tab compared to the maps.")
       
      })
      
      
      # Testing Priorities
      
      output$first<-renderUI({
        merged<-dataInput()
        merged<-merged %>% dplyr::select(COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,Percent_vax,Percent65_vax,Percent16_vax)
        rownames(merged)<-merged$CSA2010
        selectInput('col_1', 'First Priority', names(merged),selected="COVID_RATE")
      })
      
      output$firstw<-renderUI({
        numericInput('col_1w', 'First Weight', value=.33)
      })
      
      
      output$second<-renderUI({
        merged<-dataInput()
        merged<-merged %>% dplyr::select(COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,Percent_vax,Percent65_vax,Percent16_vax)
        rownames(merged)<-merged$CSA2010
        selectInput('col_2', 'Second Priority', names(merged),selected="Percent65_vax")
      })
      
      output$secondw<-renderUI({
        numericInput('col_2w', 'Second Weight', value=.33)
      })
      
      
      output$third<-renderUI({
        merged<-dataInput()
        merged<-merged %>% dplyr::select(COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,Percent_vax,Percent65_vax,Percent16_vax)
        rownames(merged)<-merged$CSA2010
        selectInput('col_3', 'Third Priority', names(merged),selected="Percent_Hospitalized")
      })
      
      output$thirdw<-renderUI({
        numericInput('col_3w', 'Third Weight', value=.33)
      })
      
      output$prior_table<-renderDataTable({
        merged<-dataInput()
        merged<-as.data.frame(merged)
        merged<-merged %>% dplyr::select(CSA2010, COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,Percent_vax,Percent65_vax,Percent16_vax)
        
        # Reverse Coding
        merged$Percent_Tested<-merged$Percent_Tested*-1
        merged$Percent_vax<-merged$Percent_vax*-1
        merged$Percent65_vax<-merged$Percent65_vax*-1
        merged$Percent16_vax<-merged$Percent16_vax*-1
        
        # Composite
        merged[is.na(merged)]<-0
        merged$score<-(ntile(merged[[input$col_1]],5)*input$col_1w)+(ntile(merged[[input$col_2]],4)*input$col_2w)+(ntile(merged[[input$col_3]],4)*input$col_3w)
        merged$Percent_Tested<-abs(merged$Percent_Tested)
        merged$Percent_vax<-abs(merged$Percent_vax)
        merged$Percent65_vax<-abs(merged$Percent65_vax)
        merged$Percent16_vax<-abs(merged$Percent16_vax)
        
        merged<-merged %>% dplyr::arrange(-score) 
        merged$Rank<-merged %>% dplyr::group_indices(-score,CSA2010) 
        merged<- merged %>% select(Rank, CSA2010, COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,Percent_vax,Percent65_vax,Percent16_vax,score)
        
        merged
      })
      
        # Priority Map
  
      output$priority_map<-renderLeaflet({
        merged<-dataInput()
        merged<-as.data.frame(merged)
        merged<-merged %>% dplyr::select(CSA2010, COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,Percent_vax,Percent65_vax)
        
        # Reverse Coding
        merged$Percent_Tested<-merged$Percent_Tested*-1
        merged$Percent_vax<-merged$Percent_vax*-1
        merged$Percent65_vax<-merged$Percent65_vax*-1
        
        # Composite
        merged[is.na(merged)]<-0
        merged$score<-(ntile(merged[[input$col_1]],5)*input$col_1w)+(ntile(merged[[input$col_2]],4)*input$col_2w)+(ntile(merged[[input$col_3]],4)*input$col_3w)
        merged$Percent_Tested<-abs(merged$Percent_Tested)
        merged<-merged %>% dplyr::arrange(-score) 
        merged$Rank<-merged %>% dplyr::group_indices(-score,CSA2010) 
        
        
        prior<- merged %>% select(Rank, CSA2010, COVID_Rate,Percent_Hospitalized,Mortality_Rate,Case_Fatality, Percent_Positive, Percent_Tested,score)
        
        
        
        # Merge and make map
        priorities<-sp::merge(bnia,prior,by=c("CSA2010"))
        prior2<-as.data.frame(priorities)
        prior2<-prior2 %>% dplyr::select(CSA2010,Rank)
        
        # Centroids for labels
        # cent = rgeos::gCentroid(priorities, byid = TRUE)
        # centers <- data.frame(coordinates(cent))
        centers<-coordinates(priorities)
        centers<-cbind(prior2,centers)
        colnames(centers)<-c("CSA2010","Rank","X","Y")
        # centers$Rank<- centers$Rank
        test<-paste0(centers$Rank)
        
        # Popups
         map_label_priority<-paste0("CSA: ",priorities$CSA2010,"<br>","Rank (1=highest): ",priorities$Rank)
      
         leaflet(priorities) %>% addTiles()%>%
           setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
           addPolygons(color = ~colorNumeric("YlOrRd",Rank,reverse=TRUE)(Rank), weight = 1,  opacity = 1.0, fillOpacity = .65,
                       label=lapply(map_label_priority,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
           addLabelOnlyMarkers(data = centers,
                               lng = ~X, lat = ~Y, label = ~test,
                               labelOptions = labelOptions(noHide = TRUE, direction = 'top', textOnly = TRUE,
                                                           style=list("font-size"="20px"),offset=c(0,20))) %>%
           addLegend(position="bottomright",pal = colorNumeric("YlOrRd",priorities$Rank,reverse=TRUE),
                     values = priorities$Rank,title="Priority Ranks")
           

      })

    # Stat Table
      output$stattable<-renderDataTable({
        dataInput() %>% select(CSA2010,COVID_Rate,cases,deaths,hospitalizations,Percent_Positive,Percent_Tested,Percent_Hospitalized,Mortality_Rate,Case_Fatality,Percent_vax,Percent65_vax,Percent16_vax)%>%
          arrange(-COVID_Rate)
      })
      
      ### Vaccinated Maps-------------------------
      # Map: Number Vaccinated - First Dose Date - All patients -----------------------------------
      output$numbervax<-renderLeaflet({
        vax_count_map <- covid_vax #%>% dplyr::filter(nursing==0)
        vax_count_map<-vax_count_map %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        
        # Summarize records by CSA+ Week
        vax_map<-aggregate(.~CSA2010+week,vax_count_map,FUN=sum)
        vax_map <- vax_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        # Aggregate by CSA
        vax_map$recs<-vax_map$vaccinated
        vax_count_map<-aggregate(recs~CSA2010,vax_map,FUN=sum)
        vax_centroids<-sp::merge(centroids,vax_count_map,by=c("CSA2010"))
        
        # Labels
        map_out_label_vax<-paste0("CSA: ",vax_centroids$CSA2010,"<br>","Vaccinated: ",vax_centroids$recs)
        
        # Factor Colors/symbols
        factpal <- colorNumeric("viridis", vax_centroids$recs)
        
        leaflet(vax_centroids) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addCircleMarkers(radius=ntile(vax_centroids$recs,4)*5,
                           color = ~factpal(recs), weight = 1,  opacity = 1.0, fillOpacity = .85,
                           label=lapply(map_out_label_vax,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorNumeric("viridis",vax_centroids$recs),
                    values = vax_centroids$recs,title="Number Vaccinated")
        
      })
      
      #### Percent Vaccinated -----
      # Map: Percent of Population (All) vaccinated ---------------------------------------
      output$pervax<-renderLeaflet({
        pervaxs <- covid_vax #%>% filter(Facilit)
        pervaxs<- pervaxs %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        pervaxs$recs<-pervaxs$vaccinated
        
        # Summarize records by CSA+ Week
        pervaxs_map<-aggregate(.~CSA2010,pervaxs,FUN=sum)
        pervaxs_map <- pervaxs_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
  
        # Aggregate by CSA
        pervaxs_map<-aggregate(.~CSA2010,pervaxs_map,FUN=sum)
        pervaxs_map<-sp::merge(bnia,pervaxs_map,by=c("CSA2010"))
        pervaxs_map$tpop10<-as.numeric(as.character(pervaxs_map$tpop10))
        pervaxs_map$percent<-round((pervaxs_map$recs/pervaxs_map$tpop10)*100,1)
        
        # Labels
        map_out_label_pervax<-paste0("CSA: ",pervaxs_map$CSA2010,"<br>","Vaccinated: ",pervaxs_map$recs,"<br>","Population: ",pervaxs_map$tpop10,"<br>","Percent: ",pervaxs_map$percent)
        
        leaflet(pervaxs_map) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("RdYlBu", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_pervax,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("RdYlBu", pervaxs_map$percent,bins=4),
                    values = pervaxs_map$percent,title=" Percent Vaccinated")
      })
      
      
      ## Percent of Total Population Vax with 2 doses / Complete
      output$pervax2<-renderLeaflet({
        pervax2<- covid_vax #%>% filter(Facilit)
        pervax2<- pervax2 %>% dplyr::filter(week>=input$start_week & week<=input$end_week & two_doses==1)
        pervax2$recs<-pervax2$vaccinated
        
        # Summarize records by CSA+ Week
        pervax2_map<-aggregate(.~CSA2010,pervax2,FUN=sum)
        pervax2_map <-pervax2_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        pervax2_map<-aggregate(.~CSA2010,pervax2_map,FUN=sum)
        pervax2_map<-sp::merge(bnia,pervax2_map,by=c("CSA2010"))
        pervax2_map$tpop10<-as.numeric(as.character(pervax2_map$tpop10))
        pervax2_map$percent<-round((pervax2_map$recs/pervax2_map$tpop10)*100,1)
        
        # Labels
        map_out_label_pervax2<-paste0("CSA: ",pervax2_map$CSA2010,"<br>","Vax Complete: ",pervax2_map$recs,"<br>","Population: ",pervax2_map$tpop10,"<br>","Percent: ",pervax2_map$percent)
        
        leaflet(pervax2_map) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("RdYlBu", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_pervax2,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("RdYlBu", pervax2_map$percent,bins=4),
                    values = pervax2_map$percent,title=" Percent Vaccinated Complete")
      })
      
      # Percent 65+
      #### Percent Vaccinated 65 and older -----
      output$pervax65<-renderLeaflet({
        per65vax<- covid_vax %>% dplyr::filter(age65==1)
        per65vax<- per65vax%>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        per65vax$recs<-per65vax$vaccinated
        
        # Summarize records by CSA+ Week
        per65vax_map<-aggregate(.~CSA2010,per65vax,FUN=sum)
        per65vax_map <- per65vax_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        per65vax_map<-aggregate(.~CSA2010,per65vax_map,FUN=sum)
        per65vax<-sp::merge(bnia,per65vax_map,by=c("CSA2010"))
        per65vax<-sp::merge(per65vax,nhp2017,by=c("CSA2010"))
        per65vax$tpop10<-per65vax$Census_NUM
        per65vax$percent<-round((per65vax$recs/per65vax$tpop10)*100,1)
        
        # Labels
        map_out_label_per65vax<-paste0("CSA: ",per65vax$CSA2010,"<br>","Vaccinated (65+): ",per65vax$recs,"<br>","Population: ",per65vax$tpop10,"<br>","Percent: ",per65vax$percent)
        
        leaflet(per65vax) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("RdYlBu", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_per65vax,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("RdYlBu", per65vax$percent,bins=4),
                    values = per65vax$percent,title=" Percent Vaccinated 65 and Older")
                  
      })
      
      #### Percent Vaccinated 65 and older-two doses -----
      
      output$pervax652<-renderLeaflet({
        pervax65_2<- covid_vax %>% dplyr::filter(age65==1)
        pervax65_2<- pervax65_2 %>% dplyr::filter(week>=input$start_week & week<=input$end_week & two_doses==1)
        pervax65_2$recs<-pervax65_2$vaccinated
        
        # Summarize records by CSA+ Week
        pervax65_2_map<-aggregate(.~CSA2010,pervax65_2,FUN=sum)
        pervax65_2_map <- pervax65_2_map %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        pervax65_2_map<-aggregate(.~CSA2010,pervax65_2_map,FUN=sum)
        pervax65_2_map<-sp::merge(bnia,pervax65_2_map,by=c("CSA2010"))
        pervax65_2_map<-sp::merge(pervax65_2_map,nhp2017,by=c("CSA2010"))
        pervax65_2_map$tpop10<-pervax65_2_map$Census_NUM
        pervax65_2_map$percent<-round((pervax65_2_map$recs/pervax65_2_map$tpop10)*100,1)
        
        # Labels
        map_out_label_pervax65_2_map<-paste0("CSA: ",pervax65_2_map$CSA2010,"<br>","Vaccinated (65+) Complete: ",pervax65_2_map$recs,"<br>","Population: ",pervax65_2_map$tpop10,"<br>","Percent: ",pervax65_2_map$percent)
        
        leaflet(pervax65_2_map) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("RdYlBu", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_pervax65_2_map,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("RdYlBu", pervax65_2_map$percent,bins=4),
                    values = pervax65_2_map$percent,title=" Percent Vaccinated 65 and Older Complete")
        
      })
      
      # Vax Table
      output$vaxtable<-renderDataTable({
        pertested <- covid_vax 
        pertested<- pertested %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        pertested$recs<-pertested$vaccinated
        pertested$recs65<-ifelse(pertested$age65==1,1,0)
        pertested$dose1_65<-ifelse(pertested$age65==1 & pertested$one_dose==1,1,0)
        pertested$dose2_65<-ifelse(pertested$age65==1 & pertested$two_doses==1,1,0)
        pertested$dose2_16yo<-ifelse(pertested$age16==1 & pertested$two_doses==1,1,0)
        
        # Summarize records by CSA+ Week
        tested_map<-aggregate(.~CSA2010,pertested,FUN=sum)
        tested_map <- tested_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        pertested_map<-aggregate(.~CSA2010,tested_map,FUN=sum)
        percent_tested<-sp::merge(bnia,pertested_map,by=c("CSA2010"))
        percent_tested<-sp::merge(percent_tested,nhp2017,by=c("CSA2010"))
        percent_tested$tpop65<-percent_tested$Census_NUM
        percent_tested$Percent_vax_65<-round((percent_tested$recs65/percent_tested$tpop65)*100,1)
        percent_tested$Percent_vax<-round((percent_tested$recs/as.numeric(as.character(percent_tested$tpop10)))*100,1)
        percent_tested$Percent16_vax<-round((percent_tested$age16plus/percent_tested$Pop_16Plus)*100,1)
        
        # two dose percent
        percent_tested$per_twodoses<-round((percent_tested$two_doses/as.numeric(as.character(percent_tested$tpop10)))*100,1)
        percent_tested$per65_twodoses<-round((percent_tested$dose2_65/percent_tested$Census_NUM)*100,1)
        
        # overdue
        percent_tested$per_overdue<-round((percent_tested$overdue/percent_tested$PM)*100,1)
          
        table_vaccinated<-as.data.frame(percent_tested)
        table_vaccinated<- table_vaccinated %>% dplyr::select(CSA2010,tpop10,tpop65,Pop_16Plus,Percent_vax_65,age65,age16plus,Percent_vax,Percent16_vax,dose1_65,dose2_65,dose2_16yo,per65_twodoses,vaccinated,one_dose,two_doses,per_twodoses,unk_doses,PM,overdue,per_overdue)
        table_vaccinated<- table_vaccinated %>% dplyr::arrange(-Percent_vax_65) %>% rename(
          Total_Population=tpop10,
          Population_65=tpop65,
          #Percent_Vax_65=percent_vax_65,
          Number_65_Vax=age65,
          Percent_Total_Vax=Percent_vax,
          Percent_16Plus_Vax=Percent16_vax,
          Total_Vax=vaccinated,
          Complete=two_doses,
          Complete65=dose2_65,
          Complete16=dose2_16yo,
          Percent_Complete=per_twodoses,
          Percent65_Complete=per65_twodoses
        )
      })
      
      # Percent Overdue
      output$overdue<-renderLeaflet({
        overdues<- covid_vax %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        overdues$recs<-overdues$vaccinated
        
        # Summarize records by CSA+ Week
        overdue_map<-aggregate(.~CSA2010,overdues,FUN=sum)
        overdue_map <- overdue_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        overdue_map<-aggregate(.~CSA2010,overdue_map,FUN=sum)
        overdue_map<-sp::merge(bnia,overdue_map,by=c("CSA2010"))
        overdue_map<-sp::merge(overdue_map,nhp2017,by=c("CSA2010"))
        overdue_map$tpop10<-overdue_map$Census_NUM
        overdue_map$percent<-round((overdue_map$overdue/overdue_map$PM)*100,1)
        
        # Labels
        map_out_label_overdue_map<-paste0("CSA: ",overdue_map$CSA2010,"<br>","Number Overdue: ",overdue_map$overdue,"<br>","Number Vaccinated: ",overdue_map$PM,"<br>","% Overdue: ",overdue_map$percent)
        
        leaflet(overdue_map) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("Reds", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_overdue_map,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("Reds", overdue_map$percent,bins=4),
                    values = overdue_map$percent,title=" Percent Overdue")
        
      })
      
      ########## Percent Eligible Population (16 and Older) Vax- 1 dose or more  -------------------------
      output$vax_eligible1<-renderLeaflet({
        elig_1vax <- covid_vax %>% dplyr::filter(age16plus==1)
        elig_1vax <-elig_1vax %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        elig_1vax$recs<- elig_1vax$vaccinated
        
        # Summarize records by CSA+ Week
        elig_1vax_map<-aggregate(.~CSA2010, elig_1vax,FUN=sum)
        elig_1vax_map<- elig_1vax_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        # Aggregate by CSA
        elig_1vax_map<-aggregate(.~CSA2010,elig_1vax_map,FUN=sum)
        elig_1vax_map<-sp::merge(bnia,elig_1vax_map,by=c("CSA2010"))
        elig_1vax_map<-sp::merge(elig_1vax_map,nhp2017,by=c("CSA2010"))
        elig_1vax_map$tpop10<-elig_1vax_map$Census_NUM
        elig_1vax_map$percent<-round((elig_1vax_map$recs/elig_1vax_map$Pop_16Plus)*100,1)
        
        # Labels
        map_out_label_elig_1vax_map<-paste0("CSA: ",elig_1vax_map$CSA2010,"<br>","Vaccinated (16+): ",elig_1vax_map$recs,"<br>","Population 16+: ",elig_1vax_map$Pop_16Plus,"<br>","Percent Eligible Vax 1 shot: ",elig_1vax_map$percent)
        
        leaflet(elig_1vax_map) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("RdYlBu", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_elig_1vax_map,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("RdYlBu", elig_1vax_map$percent,bins=4),
                    values = elig_1vax_map$percent,title=" Percent Vaccinated 16 and Older 1 or more")
      })
      
      # Percent Vax - Complete of Eligible Population
      ########## Percent Eligible Population Vax- 1 dose or more  -------------------------
      output$vax_eligible2<-renderLeaflet({
        elig_2vax<- covid_vax %>% dplyr::filter(two_doses==1 & age16plus==1)
        elig_2vax<- elig_2vax %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
        elig_2vax$recs<-elig_2vax$vaccinated
        
        # Summarize records by CSA+ Week
        elig_2vax_map<-aggregate(.~CSA2010,elig_2vax,FUN=sum)
        elig_2vax_map <- elig_2vax_map  %>% arrange(CSA2010, week)
        #tested_map<- tested_map %>% dplyr::select(-CSA2010)
        #tested_map<-merge(tested_map,covid_firstcsa,by=c("id"))
        
        
        # Aggregate by CSA
        elig_2vax_map<-aggregate(.~CSA2010,elig_2vax_map,FUN=sum)
        elig_2vax_map<-sp::merge(bnia,elig_2vax_map,by=c("CSA2010"))
        elig_2vax_map<-sp::merge(elig_2vax_map,nhp2017,by=c("CSA2010"))
        elig_2vax_map$tpop10<-elig_2vax_map$Census_NUM
        elig_2vax_map$percent<-round((elig_2vax_map$recs/elig_2vax_map$Pop_16Plus)*100,1)
        
        # Labels
        map_out_label_elig_2vax_map<-paste0("CSA: ",elig_2vax_map$CSA2010,"<br>","Vaccinated (16+): ",elig_2vax_map$recs,"<br>","Population 16+: ",elig_2vax_map$Pop_16Plus,"<br>","Percent Eligible Complete: ",elig_2vax_map$percent)
        
        leaflet(elig_2vax_map) %>% addTiles()%>%
          setView(lng = -76.63, lat = 39.295, zoom = 12) %>%
          addPolygons(color = ~colorBin("RdYlBu", percent,bins=4)(percent), weight = 1,  opacity = 1.0, fillOpacity = .5,
                      label=lapply(map_out_label_elig_2vax_map,HTML),labelOptions=labelOptions(style=list("font-size"="14px")))%>%
          addLegend(position="bottomright",pal = colorBin("RdYlBu", elig_2vax_map$percent,bins=4),
                    values = elig_2vax_map$percent,title=" Percent Vaccinated 16+ Complete")
      })
      
      ### ---Quick Vaccine Statistics-------------------------------------
      output$quick_stats<-renderText({
      quick3<-covid_vax %>% dplyr::filter(week>=input$start_week & week<=input$end_week)
      quick3$recs65<-ifelse(quick3$age65==1,1,0)
      quick3$recs<-1
      quick<-aggregate(.~CSA2010,quick3,FUN=sum)
      quick2<-sp::merge(bnia_dat,quick,by=c("CSA2010"))
      quick3<-sp::merge(quick2,nhp2017,by=c("CSA2010"))
      
      quick3$tpop65<-quick3$Census_NUM
      quick3$Percent_vax_65<-round((quick3$recs65/quick3$tpop65)*100,1)
      quick3$Percent_vax<-round((quick3$recs/as.numeric(as.character(quick3$tpop10)))*100,1)
      quick3$Percent16_vax<-round((quick3$age16plus/quick3$Pop_16Plus)*100,1)
      
      test<-as.data.frame(quick3)
      str(quick3$recs65)
      str(quick3$Census_NUM)
      test2<-test %>% select(CSA2010,recs65,Census_NUM,Percent_vax_65)
      
      HTML(paste("CSA-Level Statistics, Within CSAs: ",
                 paste("Population 65 and Older"),
                 paste("Median Percent 65 and Older Vaccinated (1 or more): ",round(median(quick3$Percent_vax_65,na.rm=TRUE),1)),
                 paste("Mean Percent 65 Vax: ",round(mean(quick3$Percent_vax_65,na.rm=TRUE),1)),
                 paste("Standard Deviation: ",round(sd(quick3$Percent_vax_65,na.rm=TRUE),1)),
                 paste("Min: ",round(min(quick3$Percent_vax_65,na.rm=TRUE),1)),
                 paste("Max: ",round(max(quick3$Percent_vax_65,na.rm=TRUE),1)),
                 "",
                 paste("Total Eligible Population (Ages 16 and Older)"),
                 paste("Median Percent 16 and Older Vaccinated (1 or more): ",round(median(quick3$Percent16_vax,na.rm=TRUE),1)),
                 paste("Mean Percent 16 and Older Vax: ",round(mean(quick3$Percent16_vax,na.rm=TRUE),1)),
                 paste("Standard Deviation: ",round(sd(quick3$Percent16_vax,na.rm=TRUE),1)),
                 paste("Min: ",round(min(quick3$Percent16_vax,na.rm=TRUE),1)),
                 paste("Max: ",round(max(quick3$Percent16_vax,na.rm=TRUE),1)),
                 "",
                 paste("Total Population - All Ages (Some not currently eligible for vax)"),
                 paste("Median Percent All Ages Vaccinated (1 or more): ",round(median(quick3$Percent_vax,na.rm=TRUE),1)),
                 paste("Mean Percent All Ages Vax: ",round(mean(quick3$Percent_vax,na.rm=TRUE),1)),
                 paste("Standard Deviation: ",round(sd(quick3$Percent_vax,na.rm=TRUE),1)),
                 paste("Min: ",round(min(quick3$Percent_vax,na.rm=TRUE),1)),
                 paste("Max: ",round(max(quick3$Percent_vax,na.rm=TRUE),1)),
                 
                 sep="\n"))
      
      
})
}

# Run the application 
shinyApp(ui = ui, server = server)
